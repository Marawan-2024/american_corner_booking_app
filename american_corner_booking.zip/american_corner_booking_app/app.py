from flask import Flask, render_template, request, send_file, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import qrcode
import io
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bookings.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    course = db.Column(db.String(100), nullable=False)
    time = db.Column(db.String(100), nullable=False)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    phone = request.form['phone']
    email = request.form['email']
    course = request.form['course']
    time = datetime.now().strftime("%Y-%m-%d %H:%M")

    booking = Booking(name=name, phone=phone, email=email, course=course, time=time)
    db.session.add(booking)
    db.session.commit()

    return redirect(url_for('view_card', id=booking.id))

@app.route('/view/<int:id>')
def view_card(id):
    booking = Booking.query.get_or_404(id)
    qr_url = request.host_url + "view/" + str(booking.id)
    img = qrcode.make(qr_url)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    qr_data = buf.getvalue()
    import base64
    qr_base64 = base64.b64encode(qr_data).decode('utf-8')

    return f"""
    <!DOCTYPE html>
    <html lang='ar' dir='rtl'>
    <head>
        <meta charset='UTF-8'>
        <title>بطاقة الاشتراك</title>
        <style>
            body {{
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(to right, #1f4037, #99f2c8);
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }}
            .card {{
                background: white;
                border-radius: 12px;
                padding: 20px;
                box-shadow: 0 0 15px rgba(0,0,0,0.2);
                text-align: center;
                max-width: 350px;
                width: 100%;
            }}
            h2 {{ color: #2c3e50; margin-bottom: 10px; }}
            p {{ font-size: 15px; color: #34495e; margin: 6px 0; }}
            img.logo {{ width: 90px; margin-bottom: 10px; }}
            .qr {{ margin-top: 15px; }}
        </style>
    </head>
    <body>
        <div class='card'>
            <img src='/static/logo.png' class='logo' alt='Logo'>
            <h2>بطاقة اشتراك</h2>
            <p><strong>الاسم:</strong> {booking.name}</p>
            <p><strong>الهاتف:</strong> {booking.phone}</p>
            <p><strong>البريد:</strong> {booking.email}</p>
            <p><strong>الكورس:</strong> {booking.course}</p>
            <p><strong>التاريخ:</strong> {booking.time}</p>
            <div class='qr'><img src='data:image/png;base64,{qr_base64}' alt='QR Code'></div>
        </div>
    </body>
    </html>
    """

@app.route('/admin')
def admin():
    password = request.args.get('passw')
    if password != "admin123":
        return "🚫 غير مصرح. استخدم /admin?passw=admin123"

    bookings = Booking.query.order_by(Booking.id.desc()).all()

    rows = ''
    for b in bookings:
        rows += f"""
        <tr>
            <td>{b.id}</td>
            <td>{b.name}</td>
            <td>{b.phone}</td>
            <td>{b.email}</td>
            <td>{b.course}</td>
            <td>{b.time}</td>
            <td>{getattr(b, 'dob', '')}</td>
            <td>
                <a href='/view/{b.id}' class='btn-view'>عرض</a>
                <a href='/delete/{b.id}' class='btn-delete' onclick="return confirm('هل أنت متأكد من الحذف؟');">حذف</a>
            </td>
        </tr>
        """

    return f"""
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>قائمة المشتركين</title>
        <style>
            body {{
                font-family: 'Segoe UI', sans-serif;
                background: #f7f9fb;
                padding: 20px;
            }}
            h2 {{
                text-align: center;
                color: #2c3e50;
            }}
            input#search {{
                width: 300px;
                padding: 10px;
                margin: 20px auto;
                display: block;
                border-radius: 8px;
                border: 1px solid #ccc;
                font-size: 16px;
                text-align: center;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                background: white;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }}
            th, td {{
                padding: 12px;
                text-align: center;
                border-bottom: 1px solid #ddd;
            }}
            th {{
                background-color: #2980b9;
                color: white;
            }}
            a.btn-view, a.btn-delete {{
                padding: 6px 10px;
                border-radius: 6px;
                text-decoration: none;
                font-size: 14px;
            }}
            .btn-view {{ background: #27ae60; color: white; }}
            .btn-delete {{ background: #c0392b; color: white; }}
            .export-btn {{
                margin: 15px 0;
                display: inline-block;
                padding: 8px 16px;
                background: #8e44ad;
                color: white;
                border-radius: 6px;
                text-decoration: none;
            }}
        </style>
    </head>
    <body>
        <h2>📋 قائمة المشتركين في الكورسات</h2>
        <a href='/export' class='export-btn'>📥 تصدير إلى Excel</a>
        <input type="text" id="search" placeholder="🔍 ابحث بالاسم أو تاريخ الميلاد">
        <table id="studentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>الاسم</th>
                    <th>الهاتف</th>
                    <th>البريد</th>
                    <th>الكورس</th>
                    <th>وقت التسجيل</th>
                    <th>تاريخ الميلاد</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
        
        <script>
            const searchInput = document.getElementById("search");
            const tableRows = document.querySelectorAll("#studentsTable tbody tr");

            searchInput.addEventListener("input", function() {{
                const searchValue = this.value.toLowerCase();
                tableRows.forEach(row => {{
                    const rowText = row.textContent.toLowerCase();
                    row.style.display = rowText.includes(searchValue) ? "" : "none";
                }});
            }});
        </script>
    </body>
    </html>
    """


@app.route('/delete/<int:id>')
def delete_booking(id):
    booking = Booking.query.get_or_404(id)
    db.session.delete(booking)
    db.session.commit()
    return redirect(url_for('admin', passw='admin123'))

@app.route('/export')
def export_excel():
    import csv
    bookings = Booking.query.all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Name', 'Phone', 'Email', 'Course', 'Time'])
    for b in bookings:
        writer.writerow([b.id, b.name, b.phone, b.email, b.course, b.time])
    output.seek(0)
    return send_file(io.BytesIO(output.read().encode()), mimetype='text/csv', download_name='bookings.csv', as_attachment=True)

if __name__ == '__main__':
    if not os.path.exists("bookings.db"):
        with app.app_context():
            db.create_all()
    app.run(debug=True)